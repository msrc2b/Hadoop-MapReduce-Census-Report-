package census;

import java.io.IOException;

import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;

public class Mapper1 extends org.apache.hadoop.mapreduce.Mapper<LongWritable, Text, Text, IntWritable> 
{
	private Text combo=new Text();
	String gender;
	String statenew; 

	@Override
	protected void map(LongWritable key, Text value,Context context)
			throws IOException, InterruptedException {
		String line = value.toString();
        String[] data = line.split(",");
        String serialno=data[0];
        String year=serialno.substring(0,4); //****************************
        String state=data[5];//**************************************
        if (state.equals("06")) {
			statenew = "California ";
		} else if (state.equals("08")) {
			statenew = "Colorado   ";
		} else if (state.equals("53")) {
			statenew = "Washington  ";
		} else if (state.equals("48")) {
			statenew = "Texas       ";
		} else if (state.equals("42")) {
			statenew = "Pennsylvania";
		} else if (state.equals("50")) {
			statenew = "Vermont     ";
		} else if (state.equals("12")) {
			statenew = "Florida     ";
		} else {
			statenew = "others";
		}
        String gender1=data[69];//**************************************
        if(gender1.equals("1"))
        {
        	gender="Male";
        }
        else
        {
        	gender="Female";
        }
        String weight=data[7];//****************************************
        
        if (!weight.equals("PWGTP") && !statenew.equals("others")) {
			int weight1 = Integer.parseInt(weight);
			combo.set(new Text(year) + "," +new Text(gender) + "," + new Text(statenew));
			context.write(combo, new IntWritable(weight1));
        }
        
      
        
        
        
        
        
        
       	  
		 
		
	}
}
	

